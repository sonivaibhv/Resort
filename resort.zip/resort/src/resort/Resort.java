/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resort;     //package name

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Resort {       //class namw

    int year = 6, site = 4;     //variable intitilization
    int k = 0;
    double arr[][] = new double[site][year];

    Resort() {
    }

    public void getData() throws FileNotFoundException, IOException {   //function name getData() to get data from the text.txt file..
        BufferedReader br = new BufferedReader(new FileReader("C:/Users/TechnoFreak/Desktop/text.txt"));
        try {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }
            String everything = sb.toString();
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 5; j++) {
                    String[] value = everything.split(",");
                    double val = Double.parseDouble(value[k]);
                    arr[i][j] = val;
                    k++;
                }
            }

        } finally {
            br.close();
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                double val1 = arr[i][j];
                System.out.print(val1);
                System.out.print(" ");

            }
            System.out.println(" ");

        }

    }

    public void EnterData() {   //Function name EnterData() to take data from the user...
        int count = 1;      //variable used to count additon of each year
        int l = 0;

        do {
            System.out.println("Enter your site '" + count + "' snowfall data");
            Scanner sc = new Scanner(System.in);        //scanner class used to take input form user
            while (!sc.hasNextDouble()) {
                System.out.println("Value should be in double character");
                System.out.println("Enter your site '" + count + "' snowfall data");

                sc.next();
            }
            double newval = sc.nextDouble();
            arr[l][year - 1] = newval;
            l++;
            count++;
        } while (count != 5);
        for (int i = 0; i < site; i++) {
            for (int j = 0; j < year; j++) {
                double val1 = arr[i][j];
                System.out.print(val1);
                System.out.print(" ");

            }
            System.out.println(" ");

        }

    }

    public void calculateSnowSite() {       //function name used to calculate snowfall of each site
        System.out.println("\nWe are calcultaing average snowfall of each sites\n");
        for (int i = 0; i < site; i++) {
            System.out.println("\n");
            double calyersn = 0;
            for (int j = 0; j < year; j++) {
                double val1 = arr[i][j];
                calyersn += val1;
                System.out.print(val1);

                System.out.print(" ");

            }
            System.out.println(" ");
            System.out.println("Average snowfall of " + (i + 1) + " site is :" + calyersn / year + "\n");

        }

    }

    public void calculateSnowYear() {   //function name used to calculate snowfall of each year.
        System.out.println("\nWe are calcultaing average snowfall of each years\n");
        for (int j = 0; j < year; j++) {
            System.out.println("\n");
            double calyersn = 0;
            for (int i = 0; i < site; i++) {
                double val1 = arr[i][j];
                calyersn += val1;
                System.out.print(val1);

                System.out.print(" ");

            }
            System.out.println(" ");
            System.out.println("Average snowfall of " + (j + 1) + " year is :" + calyersn / site + "\n");

        }

    }

    public static void main(String[] args) throws IOException {
        Resort rs = new Resort();
        rs.getData();       //function calling process of getData();
        rs.EnterData();     //function calling process of EnterData();
        rs.calculateSnowSite(); //function calling process of calculateSnowSite();
        rs.calculateSnowYear(); //function calling process of calculateSnowYear();

    }

}
        // TODO code application logic here

